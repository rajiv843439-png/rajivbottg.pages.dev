RAJIV TG BOTS — SETUP (Hindi)

Is project mein:
- Public Telegram bot directory
- Owner profile link: https://t.me/Legend_boy_3
- Top par Admin Panel button
- Supabase email/password admin login
- Admin se bot add / edit / delete
- Phone gallery se JPG, PNG, WEBP image upload (max 5 MB)
- Supabase Storage mein image save
- Supabase database mein bot details save
- Realtime database updates
- Search aur Open Telegram button
- Public users ko sirf list dekhne ki permission; changes sirf admin

IMPORTANT:
"Bot upload" ka matlab is website ki directory mein bot ki listing add karna hai.
Ye Telegram bot ka Python code execute/host nahi karta. Telegram par bot open karne ke liye username link banata hai.

A. SUPABASE DATABASE BANAYEIN
1. https://supabase.com par account/project banayein.
2. Project ke andar SQL Editor > New query kholein.
3. Is folder ka supabase-setup.sql poora paste karke Run karein.
4. Project Settings > API mein Project URL aur anon/public key copy karein.
5. config.js mein:
   SUPABASE_URL = aapka Project URL
   SUPABASE_ANON_KEY = aapki anon/public key
   Service role key kabhi config.js ya website mein mat daalein.

B. ADMIN ACCOUNT BANAYEIN
1. Supabase > Authentication > Users > Add user se apna email/password user banayein.
2. User create hone ke baad uska UUID copy karein.
3. SQL Editor mein ye query chalaayein (UUID ko apne UUID se badlein):
   insert into public.admins(user_id) values ('PASTE-USER-UUID-HERE');
4. Ab website ke Admin Panel mein wahi email/password se sign in karein.
5. Public signup website par nahi hai. Admin account sirf Supabase dashboard se owner banaye.

C. CLOUDFLARE PAGES PAR PUBLISH
1. GitHub par nayi repository banayein, e.g. rajiv-tg-bots-v2.
2. ZIP extract karke is folder ke andar ki sab files repository ke root mein upload karein.
3. Cloudflare Dashboard > Workers & Pages > Create > Pages > Connect to Git.
4. Repository select karein.
5. Framework preset: None; Build command: blank; Build output directory: / (root).
6. Deploy karein. Apna custom domain/pages.dev URL use karein.

D. IMAGE UPLOAD
Admin Panel > Sign in > Bot image > Choose file. Android par file picker khulega; Gallery/Photos ya Files se image select karein. Save par image Supabase Storage mein upload hogi.

E. BOT ADD
Bot name, username (example @MyExampleBot) aur description bharein. Save karein. Open Telegram button t.me/username kholega.

F. PURANI LISTING KYUN WAPAS AATI THI?
Purani website mein bots static code/local browser storage mein ho sakte the. Is version mein bots Supabase database se aate hain. Edit/delete database par persist hoga; deploy se list reset nahi hogi.

SECURITY
- Supabase anon key browser mein reh sakti hai; RLS policies security enforce karti hain.
- Service role key, Telegram bot token, passwords GitHub par kabhi upload na karein.
- Admin ko public signup na dein. Admin UUID sirf apne account ke liye add karein.
- Is website ko actual Telegram bot hosting samajhkar use na karein.
