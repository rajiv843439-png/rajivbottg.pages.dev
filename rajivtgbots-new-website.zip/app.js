(() => {
  const $ = id => document.getElementById(id);
  const cfg = window.APP_CONFIG || {};
  const configured = cfg.SUPABASE_URL && !cfg.SUPABASE_URL.includes("YOUR-PROJECT")
    && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_ANON_KEY.includes("YOUR_SUPABASE");
  const db = configured && window.supabase ? window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY) : null;
  let bots = [], session = null, imagePath = null;
  $("year").textContent = new Date().getFullYear();

  const safe = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const telegramName = value => value.trim().replace(/^@/,"").replace(/^https?:\/\/t\.me\//i,"").replace(/\/.*$/,"");
  const validUsername = value => /^[A-Za-z0-9_]{5,32}$/.test(telegramName(value));

  function render() {
    const q = $("search").value.trim().toLowerCase();
    const shown = bots.filter(b => `${b.name} ${b.username} ${b.description||""}`.toLowerCase().includes(q));
    $("botCount").textContent = bots.length;
    $("botGrid").innerHTML = shown.length ? shown.map(b => `
      <article class="card"><div class="card-top">
      ${b.image_url ? `<img class="bot-img" src="${safe(b.image_url)}" alt="">` : `<div class="bot-img fallback">${safe((b.name||"B").slice(0,1).toUpperCase())}</div>`}
      <div><h3>${safe(b.name)}</h3><div class="username">@${safe(b.username)}</div></div></div>
      <p class="description">${safe(b.description || "Open this bot on Telegram.")}</p>
      <a class="open-btn" href="https://t.me/${encodeURIComponent(b.username)}" target="_blank" rel="noopener">Open Telegram ↗</a></article>`).join("") : `<div class="empty">No bots found. Try another search.</div>`;
    $("manageList").innerHTML = bots.length ? bots.map(b=>`<div class="manage-item"><div><b>${safe(b.name)}</b><small>@${safe(b.username)}</small></div><div class="manage-actions"><button data-edit="${b.id}">Edit</button><button class="danger" data-delete="${b.id}">Delete</button></div></div>`).join("") : `<div class="muted">No bots added yet.</div>`;
  }
  async function loadBots() {
    if (!db) { $("status").textContent = "Setup required"; $("botGrid").innerHTML = `<div class="empty">Connect your Supabase project using config.js and run supabase-setup.sql. Then bots will appear here.</div>`; return; }
    const {data,error}=await db.from("bots").select("*").order("created_at",{ascending:false});
    if(error){$("status").textContent="Database error";$("botGrid").innerHTML=`<div class="empty">${safe(error.message)}</div>`;return;}
    bots=data||[]; $("status").textContent="Live directory"; render();
  }
  function showAdmin(){ $("adminModal").classList.remove("hidden"); }
  function hideAdmin(){ $("adminModal").classList.add("hidden"); }
  function authUI(){ $("authBox").classList.toggle("hidden",!!session); $("dashboard").classList.toggle("hidden",!session); }
  function resetForm(){ $("botForm").reset(); $("editId").value=""; imagePath=null; $("imagePreview").classList.add("hidden"); $("saveBtn").textContent="Add bot"; $("formMessage").textContent=""; }
  $("adminOpen").onclick=showAdmin; $("closeAdmin").onclick=hideAdmin; $("adminModal").onclick=e=>{if(e.target===$("adminModal"))hideAdmin();};
  $("search").addEventListener("input",render);
  $("loginBtn").onclick=async()=>{
    if(!db){$("authMessage").textContent="First configure Supabase in config.js.";return;}
    $("authMessage").textContent="Signing in…";
    const {data,error}=await db.auth.signInWithPassword({email:$("email").value.trim(),password:$("password").value});
    if(error){$("authMessage").textContent=error.message;return;}
    session=data.session;authUI();$("authMessage").textContent="";loadBots();
  };
  $("logoutBtn").onclick=async()=>{await db.auth.signOut();session=null;authUI();resetForm();};
  $("resetBtn").onclick=resetForm;
  $("botImage").onchange=()=>{const f=$("botImage").files[0];if(!f)return;if(f.size>5*1024*1024){$("formMessage").textContent="Image must be 5 MB or smaller."; $("botImage").value="";return;}const url=URL.createObjectURL(f);$("imagePreview").innerHTML=`<img src="${url}" alt="Preview">`; $("imagePreview").classList.remove("hidden");};
  $("botForm").onsubmit=async e=>{
    e.preventDefault(); if(!db||!session)return;
    const name=$("botName").value.trim(), username=telegramName($("botUsername").value);
    if(!validUsername(username)){$("formMessage").textContent="Enter a valid Telegram bot username (5–32 letters, numbers or underscores).";return;}
    $("saveBtn").disabled=true;$("formMessage").textContent="Saving…";
    try{
      const file=$("botImage").files[0];
      if(file){const ext=(file.name.split(".").pop()||"jpg").toLowerCase();const path=`${crypto.randomUUID()}.${ext}`;
        const up=await db.storage.from("bot-images").upload(path,file,{upsert:false,contentType:file.type});
        if(up.error)throw up.error; imagePath=path;
      }
      const payload={name,username,description:$("botDescription").value.trim(),image_path:imagePath};
      if(imagePath){const pub=db.storage.from("bot-images").getPublicUrl(imagePath);payload.image_url=pub.data.publicUrl;}
      const id=$("editId").value;
      const result=id?await db.from("bots").update(payload).eq("id",id):await db.from("bots").insert(payload);
      if(result.error)throw result.error;
      $("formMessage").textContent="Saved successfully.";resetForm();await loadBots();
    }catch(err){$("formMessage").textContent=err.message||"Could not save bot.";}
    finally{$("saveBtn").disabled=false;}
  };
  $("manageList").onclick=async e=>{
    const edit=e.target.dataset.edit, del=e.target.dataset.delete;
    if(edit){const b=bots.find(x=>String(x.id)===edit);if(!b)return;$("editId").value=b.id;$("botName").value=b.name;$("botUsername").value="@"+b.username;$("botDescription").value=b.description||"";imagePath=b.image_path||null;$("saveBtn").textContent="Save changes";$("formMessage").textContent="Editing bot. Choose a new image only if you want to replace it.";return;}
    if(del){const b=bots.find(x=>String(x.id)===del);if(!b||!confirm(`Delete ${b.name} from the directory?`))return;
      const {error}=await db.from("bots").delete().eq("id",del);if(error){alert(error.message);return;}
      if(b.image_path)await db.storage.from("bot-images").remove([b.image_path]);await loadBots();}
  };
  async function init(){
    if(!db){loadBots();return;}
    const {data}=await db.auth.getSession();session=data.session;authUI();
    await loadBots();
    db.channel("bots-live").on("postgres_changes",{event:"*",schema:"public",table:"bots"},loadBots).subscribe();
  }
  init();
})();