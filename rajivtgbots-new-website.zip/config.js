// Public Supabase project settings. Replace both values before deploying.
// The anon key is designed for browser use; NEVER put a service_role key here.
window.APP_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY"
};